using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using RaceDayData.Data;
using RaceDayModel.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RaceDayApp.Controllers;

[ApiController]
public class RaceDayController : ControllerBase
{
    private readonly RaceDayDataContext _context;
    private const string SecretKey = "RaceDaySuperSecretKeyThatIsAtLeast32CharactersLong!";

    public RaceDayController(RaceDayDataContext context)
    {
        _context = context;
    }

    
    // 1. AUTHENTICATION ENDPOINTS
   

    [HttpPost("api/auth/register")]
    public IActionResult Register([FromBody] Users newUser)
    {
        if (_context.Users.Any(u => u.Email == newUser.Email))
            return Conflict("Email already registered.");

        _context.Users.Add(newUser);
        _context.SaveChanges();

        var token = CreateJwtToken(newUser);
        return StatusCode(201, new
        {
            message = "User registered successfully",
            token,
            user = newUser
        });
    }

    [HttpPost("api/auth/login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        var user = _context.Users.FirstOrDefault(u => u.Email == request.Email && u.Password == request.Password);
        if (user == null)
            return Unauthorized("Invalid email or password.");

        var token = CreateJwtToken(user);
        return Ok(new { token, role = user.Role });
    }

  
    // 2. USER PROFILE ENDPOINTS


    [Authorize]
    [HttpGet("api/users/profile")]
    public IActionResult GetProfile()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        return Ok(user);
    }

    [Authorize]
    [HttpPut("api/users/profile")]
    public IActionResult UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        user.PhoneNumber = request.Phone;
        _context.SaveChanges();

        return Ok(user);
    }


    // 3. EVENTS ENDPOINTS
   

    // View all events
    [HttpGet("api/events")]
    public IActionResult GetEvents(
        [FromQuery] string? eventType,
        [FromQuery] DateOnly? date)
    {
        var query = _context.Events.AsQueryable();

        if (!string.IsNullOrWhiteSpace(eventType))
            query = query.Where(e => e.EventType == eventType);

        if (date.HasValue)
            query = query.Where(e => e.EventDate == date.Value);

        return Ok(query.ToList());
    }

    // View events belonging to the logged-in organiser
    [Authorize(Roles = "Organiser")]
    [HttpGet("api/events/organiser")]
    public IActionResult GetOrganiserEvents()
    {
        var organiserId =
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(organiserId))
            return Unauthorized();

        var events = _context.Events
            .Where(e => e.OrganiserID == organiserId)
            .ToList();

        return Ok(events);
    }

    // Create event
    [Authorize(Roles = "Organiser")]
    [HttpPost("api/events")]
    public IActionResult CreateEvent(
        [FromBody] EventRequest request)
    {
        if (request == null ||
            string.IsNullOrWhiteSpace(request.EventName) ||
            string.IsNullOrWhiteSpace(request.Description) ||
            string.IsNullOrWhiteSpace(request.Location) ||
            string.IsNullOrWhiteSpace(request.Distance) ||
            string.IsNullOrWhiteSpace(request.EventType) ||
            request.EventDate == default)
        {
            return BadRequest("Please provide all required event details.");
        }

        var organiserId =
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(organiserId))
            return Unauthorized();

        // Create a venue record for the event location
        var venue = new Venue
        {
            VenueID = Guid.NewGuid().ToString(),
            VenueName = request.Location,
            City = "",
            Province = ""
        };

        _context.Venue.Add(venue);

        var newEvent = new Events
        {
            EventID = Guid.NewGuid().ToString(),
            OrganiserID = organiserId,
            VenueID = venue.VenueID,
            EventName = request.EventName,
            Description = request.Description,
            EventDate = request.EventDate,
            Location = request.Location,
            Distance = request.Distance,
            EventType = request.EventType
        };

        _context.Events.Add(newEvent);

        _context.SaveChanges();

        return StatusCode(201, newEvent);
    }

    // View individual event
    [HttpGet("api/events/{id}")]
    public IActionResult GetEventById(string id)
    {
        var raceEvent = _context.Events.Find(id);

        if (raceEvent == null)
            return NotFound("Event not found.");

        var categories = _context.Categories
            .Where(c => c.EventID == id)
            .ToList();

        return Ok(new
        {
            raceEvent,
            categories
        });
    }

    // Edit event
    [Authorize(Roles = "Organiser")]
    [HttpPut("api/events/{id}")]
    public IActionResult UpdateEvent(
        string id,
        [FromBody] EventRequest request)
    {
        var organiserId =
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var raceEvent = _context.Events.Find(id);

        if (raceEvent == null)
            return NotFound("Event not found.");

        if (raceEvent.OrganiserID != organiserId)
            return Forbid();

        if (request == null ||
            string.IsNullOrWhiteSpace(request.EventName) ||
            string.IsNullOrWhiteSpace(request.Description) ||
            string.IsNullOrWhiteSpace(request.Location) ||
            string.IsNullOrWhiteSpace(request.Distance) ||
            string.IsNullOrWhiteSpace(request.EventType) ||
            request.EventDate == default)
        {
            return BadRequest("Please provide all required event details.");
        }

        raceEvent.EventName = request.EventName;
        raceEvent.Description = request.Description;
        raceEvent.EventDate = request.EventDate;
        raceEvent.Location = request.Location;
        raceEvent.Distance = request.Distance;
        raceEvent.EventType = request.EventType;

        var venue = _context.Venue.Find(raceEvent.VenueID);

        if (venue != null)
            venue.VenueName = request.Location;

        _context.SaveChanges();

        return Ok(raceEvent);
    }

    // Delete event
    [Authorize(Roles = "Organiser")]
    [HttpDelete("api/events/{id}")]
    public IActionResult DeleteEvent(string id)
    {
        var organiserId =
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var raceEvent = _context.Events.Find(id);

        if (raceEvent == null)
            return NotFound("Event not found.");

        if (raceEvent.OrganiserID != organiserId)
            return Forbid();

        var categories = _context.Categories
            .Where(c => c.EventID == id)
            .ToList();

        var categoryIds = categories
            .Select(c => c.CategoryID)
            .ToList();

        var enrolments = _context.Enrolments
            .Where(e => categoryIds.Contains(e.CategoryID))
            .ToList();

        var enrolmentIds = enrolments
            .Select(e => e.EnrolmentID)
            .ToList();

        var results = _context.Results
            .Where(r => enrolmentIds.Contains(r.EnrolmentID))
            .ToList();

        // Remove dependent records first
        _context.Results.RemoveRange(results);
        _context.Enrolments.RemoveRange(enrolments);
        _context.Categories.RemoveRange(categories);

        _context.Events.Remove(raceEvent);

        // Remove venue if no other event uses it
        var otherEvents = _context.Events
            .Where(e => e.VenueID == raceEvent.VenueID
                     && e.EventID != id)
            .ToList();

        if (!otherEvents.Any())
        {
            var venue = _context.Venue.Find(raceEvent.VenueID);

            if (venue != null)
                _context.Venue.Remove(venue);
        }

        _context.SaveChanges();

        return Ok(new
        {
            message = "Event deleted successfully."
        });
    }

    // Add category to event
    [Authorize(Roles = "Organiser")]
    [HttpPost("api/events/{id}/categories")]
    public IActionResult AddCategory(
        string id,
        [FromBody] Categories newCategory)
    {
        var organiserId =
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var raceEvent = _context.Events.Find(id);

        if (raceEvent == null)
            return NotFound("Event not found.");

        if (raceEvent.OrganiserID != organiserId)
            return Forbid();

        if (string.IsNullOrWhiteSpace(newCategory.CategoryName) ||
            string.IsNullOrWhiteSpace(newCategory.Distance))
        {
            return BadRequest("Category name and distance are required.");
        }

        newCategory.CategoryID = Guid.NewGuid().ToString();
        newCategory.EventID = id;

        _context.Categories.Add(newCategory);
        _context.SaveChanges();

        return StatusCode(201, newCategory);
    }

    // View categories belonging to an event
    [HttpGet("api/events/{id}/categories")]
    public IActionResult GetCategoriesForEvent(string id)
    {
        var categories = _context.Categories
            .Where(c => c.EventID == id)
            .ToList();

        return Ok(categories);
    }


    // 4. ENROLMENT ENDPOINTS
  

    // Register a participant for an event
    [Authorize(Roles = "Participant")]
    [HttpPost("api/enrolments")]
    public IActionResult Enrol([FromBody] EnrolmentRequest request)
    {
        // Identify logged-in participant
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
            return Unauthorized("Participant account could not be identified.");

        // Validate request
        if (request == null ||
            string.IsNullOrWhiteSpace(request.EventID) ||
            string.IsNullOrWhiteSpace(request.CategoryID))
        {
            return BadRequest("Please select an event and category.");
        }

        // Find selected category
        var category = _context.Categories
            .FirstOrDefault(c => c.CategoryID == request.CategoryID);

        if (category == null)
            return NotFound("Selected race category was not found.");

        // Ensure category belongs to selected event
        if (category.EventID != request.EventID)
            return BadRequest("Selected category does not belong to this event.");

        // Get all categories belonging to the event
        var eventCategoryIds = _context.Categories
            .Where(c => c.EventID == request.EventID)
            .Select(c => c.CategoryID)
            .ToList();

        // Prevent duplicate enrolment in the same event
        bool alreadyEnrolled = _context.Enrolments.Any(e =>
            e.ParticipantID == userId &&
            eventCategoryIds.Contains(e.CategoryID));

        if (alreadyEnrolled)
            return Conflict("You have already enrolled in this event.");

        // Create enrolment record
        var enrolment = new Enrolments
        {
            EnrolmentID = Guid.NewGuid().ToString(),
            ParticipantID = userId,
            CategoryID = request.CategoryID,
            RegistrationDate = DateOnly.FromDateTime(DateTime.Today)
        };

        _context.Enrolments.Add(enrolment);
        _context.SaveChanges();

        return StatusCode(StatusCodes.Status201Created, new
        {
            message = "You have successfully enrolled in this event!",
            enrolment
        });
    }

    // View enrolments belonging to logged-in participant
    [Authorize(Roles = "Participant")]
    [HttpGet("api/enrolments/my-entries")]
    public IActionResult GetMyEntries()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
            return Unauthorized();

        var myEnrolments = _context.Enrolments
            .Where(e => e.ParticipantID == userId)
            .ToList();

        return Ok(myEnrolments);
    }


    // 5. RESULTS ENDPOINTS


    [Authorize(Roles = "Organiser")]
    [HttpPost("api/results")]
    public IActionResult RecordResult([FromBody] RaceDayModel.Models.Results result)
    {
        if (result == null)
            return BadRequest("Result payload cannot be null.");

        _context.Results.Add(result);
        _context.SaveChanges();

        return StatusCode(StatusCodes.Status201Created, result);
    }

    [Authorize(Roles = "Organiser")]
    [HttpGet("api/results/event/{eventId}")]
    public IActionResult GetLeaderboard(string eventId)
    {
        var organiserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var raceEvent = _context.Events.Find(eventId);

        if (raceEvent == null)
            return NotFound("Event not found.");

        if (raceEvent.OrganiserID != organiserId)
            return Forbid();

        var categoryIds = _context.Categories
            .Where(c => c.EventID == eventId)
            .Select(c => c.CategoryID)
            .ToList();

        var enrolmentIds = _context.Enrolments
            .Where(e => categoryIds.Contains(e.CategoryID))
            .Select(e => e.EnrolmentID)
            .ToList();

        var leaderboard = _context.Results
            .Where(r => enrolmentIds.Contains(r.EnrolmentID))
            .OrderBy(r => r.Position)
            .ToList();

        return Ok(leaderboard);
    }

    [Authorize(Roles = "Participant")]
    [HttpGet("api/results/my-history")]
    public IActionResult GetMyHistory()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var myEnrolmentIds = _context.Enrolments
            .Where(e => e.ParticipantID == userId)
            .Select(e => e.EnrolmentID)
            .ToList();

        var history = _context.Results
            .Where(r => myEnrolmentIds.Contains(r.EnrolmentID))
            .ToList();

        return Ok(history);
    }

    
    // TOKEN GENERATOR HELPER


    private string CreateJwtToken(Users user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
        var token = new JwtSecurityToken(
            claims: new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserID),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Email, user.Email)
            },
            expires: DateTime.UtcNow.AddHours(4),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}