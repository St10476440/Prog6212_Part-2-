﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDay.Services;
using RaceDay.Models;
using System.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;

namespace RaceDay.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly RaceDayApiService _api;

        public ParticipantController(RaceDayApiService api)
        {
            _api = api;
        }

        // Participant Dashboard
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            ViewBag.Email = HttpContext.Session.GetString("Email");

            return View();
        }

        // Upcoming Events
        public async Task<IActionResult> Events()
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            try
            {
                var events =
                    await _api.GetAsync<List<ParticipantEventViewModel>>(
                        "api/events");

                return View(events ?? new List<ParticipantEventViewModel>());
            }
            catch
            {
                ViewBag.ErrorMessage =
                    "Unable to load events. Please check that the API is running.";

                return View(new List<ParticipantEventViewModel>());
            }
        }

        // Event Details and Available Categories
        public async Task<IActionResult> EventDetails(string id)
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Invalid event ID.");

            try
            {
                var events =
                    await _api.GetAsync<List<ParticipantEventViewModel>>(
                        "api/events");

                var selectedEvent =
                    events?.FirstOrDefault(e => e.EventID == id);

                if (selectedEvent == null)
                    return NotFound("Event not found.");

                var categories =
                    await _api.GetAsync<List<ParticipantCategoryViewModel>>(
                        $"api/events/{id}/categories");

                var model = new ParticipantEventDetailsViewModel
                {
                    EventID = selectedEvent.EventID,
                    EventName = selectedEvent.EventName,
                    EventType = selectedEvent.EventType,
                    EventDate = selectedEvent.EventDate,
                    Location = selectedEvent.Location,
                    Description = selectedEvent.Description,
                    Distance = selectedEvent.Distance,
                    Categories = categories ??
                        new List<ParticipantCategoryViewModel>()
                };

                return View(model);
            }
            catch
            {
                TempData["ErrorMessage"] =
                    "Unable to load event details. Please try again.";

                return RedirectToAction("Events");
            }
        }

        // My Enrolments
        public async Task<IActionResult> MyEnrolments()
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            try
            {
                var token = HttpContext.Session.GetString("Token");

                var enrolments =
                    await _api.GetAsync<List<ParticipantEnrolmentViewModel>>(
                        "api/enrolments/my-entries", token);

                return View(
                    enrolments ?? new List<ParticipantEnrolmentViewModel>());
            }
            catch
            {
                ViewBag.ErrorMessage = "Unable to load your enrolments.";

                return View(new List<ParticipantEnrolmentViewModel>());
            }
        }

        // My Results
        public async Task<IActionResult> MyResults()
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            try
            {
                var token = HttpContext.Session.GetString("Token");

                var results =
                    await _api.GetAsync<List<ParticipantResultViewModel>>(
                        "api/results/my-history", token);

                return View(
                    results ?? new List<ParticipantResultViewModel>());
            }
            catch
            {
                ViewBag.ErrorMessage = "Unable to load your race results.";

                return View(new List<ParticipantResultViewModel>());
            }
        }

        // Enrol Participant in a Race Event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enrol(
            string eventId, string categoryId)
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(eventId) ||
                string.IsNullOrWhiteSpace(categoryId))
            {
                TempData["ErrorMessage"] =
                    "Please select a race category.";

                return RedirectToAction("EventDetails",
                    new { id = eventId });
            }

            try
            {
                var token = HttpContext.Session.GetString("Token");

                if (string.IsNullOrWhiteSpace(token))
                    return RedirectToAction("Login", "Account");

                var request = new
                {
                    EventID = eventId,
                    CategoryID = categoryId
                };

                await _api.PostAsync<object>(
                    "api/enrolments", request, token);

                TempData["SuccessMessage"] =
                    "You have successfully enrolled in this event!";

                return RedirectToAction("MyEnrolments");
            }
            catch (HttpRequestException ex)
            {
                if (ex.StatusCode == HttpStatusCode.Conflict)
                {
                    TempData["ErrorMessage"] =
                        "You have already enrolled in this event.";
                }
                else
                {
                    TempData["ErrorMessage"] =
                        "Your enrolment could not be completed. Please try again.";
                }

                return RedirectToAction("EventDetails",
                    new { id = eventId });
            }
            catch
            {
                TempData["ErrorMessage"] =
                    "Something went wrong while processing your enrolment.";

                return RedirectToAction("EventDetails",
                    new { id = eventId });
            }
        }
    }
}
