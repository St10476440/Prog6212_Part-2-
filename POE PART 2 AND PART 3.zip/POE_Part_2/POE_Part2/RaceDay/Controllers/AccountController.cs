﻿
using Microsoft.AspNetCore.Mvc;
using RaceDay.Models;
using RaceDay.Services;
using System.Text.Json;
using System.Net.Http.Json;

namespace RaceDay.Controllers
{
    public class AccountController : Controller
    {
        private readonly RaceDayApiService _api;

        public AccountController(RaceDayApiService api)
        {
            _api = api;
        }

        // GET: Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var response = await _api.PostAsync(
                    "api/auth/login",
                    new
                    {
                        model.Email,
                        model.Password
                    });

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Invalid email or password.");

                    return View(model);
                }

                var result =
                    await response.Content.ReadFromJsonAsync<LoginResponse>();

                if (result == null ||
                    string.IsNullOrWhiteSpace(result.Token))
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Unable to process login.");

                    return View(model);
                }

                // Identify the logged-in user
                var userId = GetUserIdFromToken(result.Token);

                if (string.IsNullOrWhiteSpace(userId))
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Could not identify your account.");

                    return View(model);
                }

                // Normalise the account role
                var role = result.Role?.Trim();

                if (string.Equals(
                    role, "Organiser",
                    StringComparison.OrdinalIgnoreCase))
                {
                    role = "Organiser";
                }
                else if (string.Equals(
                    role, "Participant",
                    StringComparison.OrdinalIgnoreCase))
                {
                    role = "Participant";
                }
                else
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Your account has an invalid role. Please contact the administrator.");

                    return View(model);
                }

                // Clear previous session information
                HttpContext.Session.Clear();

                // Store new login information
                HttpContext.Session.SetString("Token", result.Token);
                HttpContext.Session.SetString("Role", role);
                HttpContext.Session.SetString("UserID", userId);
                HttpContext.Session.SetString("Email", model.Email);

                // Redirect according to account role
                if (role == "Organiser")
                {
                    return RedirectToAction(
                        "Dashboard", "Organiser");
                }

                if (role == "Participant")
                {
                    return RedirectToAction(
                        "Index", "Participant");
                }

                return RedirectToAction("Login");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to RaceDay API. Please try again.");

                return View(model);
            }
        }

        // GET: Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var role = model.Role?.Trim();

            if (role != "Participant" && role != "Organiser")
            {
                ModelState.AddModelError(
                    "Role", "Please select a valid role.");

                return View(model);
            }

            try
            {
                var response = await _api.PostAsync(
                    "api/auth/register",
                    new
                    {
                        UserID = Guid.NewGuid().ToString(),
                        FullName = model.FullName,
                        Email = model.Email,
                        Password = model.Password,
                        PhoneNumber = model.PhoneNumber,
                        Role = role
                    });

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Registration failed. This email may already be registered.");

                    return View(model);
                }

                TempData["Success"] =
                    "Registration successful! Please log in.";

                return RedirectToAction("Login");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to RaceDay API.");

                return View(model);
            }
        }

        // LOGOUT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }

        // Extract user ID from JWT
        private string? GetUserIdFromToken(string token)
        {
            try
            {
                var parts = token.Split('.');

                if (parts.Length != 3)
                    return null;

                var payload = parts[1]
                    .Replace('-', '+')
                    .Replace('_', '/');

                payload = payload.PadRight(
                    payload.Length + (4 - payload.Length % 4) % 4,
                    '=');

                var json = Convert.FromBase64String(payload);

                using var document = JsonDocument.Parse(json);

                var claims = document.RootElement;

                if (claims.TryGetProperty("nameid", out var nameId))
                    return nameId.GetString();

                if (claims.TryGetProperty(
                    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                    out var identifier))
                    return identifier.GetString();

                return null;
            }
            catch
            {
                return null;
            }
        }

        // Login API response model
        private class LoginResponse
        {
            public string Token { get; set; } = string.Empty;
            public string Role { get; set; } = string.Empty;
        }
    }
}
