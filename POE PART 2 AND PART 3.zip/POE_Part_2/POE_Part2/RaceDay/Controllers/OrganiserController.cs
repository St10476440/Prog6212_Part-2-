
using Microsoft.AspNetCore.Mvc;
using RaceDay.Models;
using RaceDay.Services;

namespace RaceDay.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly RaceDayApiService _api;

        public OrganiserController(RaceDayApiService api)
        {
            _api = api;
        }

        private bool IsOrganiser()
        {
            return HttpContext.Session.GetString("Role")
                   == "Organiser";
        }

        private string? GetToken()
        {
            return HttpContext.Session.GetString("Token");
        }

        // Organiser dashboard
        public async Task<IActionResult> Dashboard()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            ViewBag.Email = HttpContext.Session.GetString("Email");

            try
            {
                var events = await _api.GetAsync<List<EventViewModel>>(
                    "api/events/organiser", GetToken());

                ViewBag.TotalEvents = events?.Count ?? 0;

                return View();
            }
            catch
            {
                ViewBag.TotalEvents = 0;
                TempData["Error"] = "Unable to load event information.";
                return View();
            }
        }

        // View all organiser events
        public async Task<IActionResult> Events()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            try
            {
                var events = await _api.GetAsync<List<EventViewModel>>(
                    "api/events/organiser", GetToken());

                return View(events ?? new List<EventViewModel>());
            }
            catch
            {
                TempData["Error"] = "Unable to retrieve your events.";

                return View(new List<EventViewModel>());
            }
        }

        // GET: Create event
        [HttpGet]
        public IActionResult CreateEvent()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            return View(new EventViewModel());
        }

        // POST: Create event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEvent(EventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var response = await _api.PostAsync(
                    "api/events",
                    model,
                    GetToken());

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "The API could not create this event.");

                    return View(model);
                }

                TempData["Success"] = "Event created successfully!";

                return RedirectToAction("Events");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to the API.");

                return View(model);
            }
        }

        // GET: Edit event
        [HttpGet]
        public async Task<IActionResult> EditEvent(string id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            try
            {
                var events = await _api.GetAsync<List<EventViewModel>>(
                    "api/events/organiser", GetToken());

                var selectedEvent = events?.FirstOrDefault(
                    e => e.EventID == id);

                if (selectedEvent == null)
                    return NotFound();

                return View(selectedEvent);
            }
            catch
            {
                TempData["Error"] = "Unable to load event.";
                return RedirectToAction("Events");
            }
        }

        // POST: Edit event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEvent(
            string id, EventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            if (id != model.EventID)
                return BadRequest();

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var response = await _api.PutAsync(
                    $"api/events/{id}",
                    model,
                    GetToken());

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Unable to update this event.");

                    return View(model);
                }

                TempData["Success"] = "Event updated successfully!";

                return RedirectToAction("Events");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to the API.");

                return View(model);
            }
        }

        // POST: Delete event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(string id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            try
            {
                var response = await _api.DeleteAsync(
                    $"api/events/{id}", GetToken());

                if (!response.IsSuccessStatusCode)
                {
                    TempData["Error"] =
                        "The event could not be deleted.";

                    return RedirectToAction("Events");
                }

                TempData["Success"] = "Event deleted successfully!";
            }
            catch
            {
                TempData["Error"] =
                    "Unable to connect to the API.";
            }

            return RedirectToAction("Events");
        }
    }
}
