﻿
namespace RaceDay.Models
{
    public class ParticipantCategoryViewModel
    {
        public string CategoryID { get; set; } = "";
        public string EventID { get; set; } = "";
        public string CategoryName { get; set; } = "";
        public string Distance { get; set; } = "";
        public string Country { get; set; } = "";
    }
}
