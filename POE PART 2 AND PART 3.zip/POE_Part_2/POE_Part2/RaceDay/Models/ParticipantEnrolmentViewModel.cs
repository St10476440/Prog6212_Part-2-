﻿
namespace RaceDay.Models
{
    public class ParticipantEnrolmentViewModel
    {
        public string EnrolmentID { get; set; } = "";

        public string ParticipantID { get; set; } = "";

        public string CategoryID { get; set; } = "";

        public DateOnly RegistrationDate { get; set; }
    }
}
