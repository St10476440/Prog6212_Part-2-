﻿
namespace RaceDay.Models
{
    public class ParticipantEventDetailsViewModel
    {
        public string EventID { get; set; } = "";
        public string EventName { get; set; } = "";
        public string EventType { get; set; } = "";
        public DateOnly EventDate { get; set; }
        public string Location { get; set; } = "";
        public string Description { get; set; } = "";
        public string Distance { get; set; } = "";

        public List<ParticipantCategoryViewModel> Categories
        {
            get; set;
        } = new List<ParticipantCategoryViewModel>();
    }
}
