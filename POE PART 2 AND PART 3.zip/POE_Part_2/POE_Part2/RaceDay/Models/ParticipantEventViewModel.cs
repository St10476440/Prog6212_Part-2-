﻿namespace RaceDay.Models
{
    public class ParticipantEventViewModel
    {
        public string EventID { get; set; } = "";
        public string EventName { get; set; } = "";
        public string EventType { get; set; } = "";
        public DateOnly EventDate { get; set; }

        public string Location { get; set; } = "";
        public string Description { get; set; } = "";
        public string Distance { get; set; } = "";
    }
}