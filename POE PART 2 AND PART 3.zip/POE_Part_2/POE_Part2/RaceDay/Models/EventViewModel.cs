﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.Models
{
    public class EventViewModel
    {
        public string EventID { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event name is required")]
        public string EventName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event date is required")]
        [DataType(DataType.Date)]
        public DateOnly EventDate { get; set; }

        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Distance is required")]
        public string Distance { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event type is required")]
        public string EventType { get; set; } = string.Empty;
    }
}
