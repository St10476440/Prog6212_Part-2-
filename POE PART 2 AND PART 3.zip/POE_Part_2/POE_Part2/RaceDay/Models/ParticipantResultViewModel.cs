﻿
namespace RaceDay.Models
{
    public class ParticipantResultViewModel
    {
        public string ResultsID { get; set; } = "";

        public string EnrolmentID { get; set; } = "";

        public TimeOnly FinishTime { get; set; }

        public string Position { get; set; } = "";

        public string Status { get; set; } = "";
    }
}
