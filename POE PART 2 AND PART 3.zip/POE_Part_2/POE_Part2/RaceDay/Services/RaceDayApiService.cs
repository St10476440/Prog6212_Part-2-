﻿
using System.Net.Http.Json;

namespace RaceDay.Services
{
    public class RaceDayApiService
    {
        private readonly HttpClient _httpClient;

        public RaceDayApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<T?> GetAsync<T>(
            string endpoint, string? token = null)
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Get, endpoint);

            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token);
            }

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<T>();
        }

        public async Task<HttpResponseMessage> PostAsync<T>(
            string endpoint, T data, string? token = null)
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Post, endpoint);

            request.Content = JsonContent.Create(data);

            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token);
            }

            return await _httpClient.SendAsync(request);
        }

        public async Task<HttpResponseMessage> PutAsync<T>(
            string endpoint, T data, string? token = null)
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Put, endpoint);

            request.Content = JsonContent.Create(data);

            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token);
            }

            return await _httpClient.SendAsync(request);
        }

        public async Task<HttpResponseMessage> DeleteAsync(
            string endpoint, string? token = null)
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Delete, endpoint);

            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token);
            }

            return await _httpClient.SendAsync(request);
        }
    }
}
